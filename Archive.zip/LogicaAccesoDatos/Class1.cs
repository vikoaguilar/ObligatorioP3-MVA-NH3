﻿namespace LogicaAccesoDatos;

public class Class1
{
}