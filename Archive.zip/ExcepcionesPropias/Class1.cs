﻿namespace ExcepcionesPropias;

public class Class1
{
}