﻿namespace LogicaAplicacion;

public class Class1
{
}