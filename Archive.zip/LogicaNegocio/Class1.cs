﻿namespace LogicaNegocio;

public class Class1
{
}